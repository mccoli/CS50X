#include <stdio.h>
#include <cs50.h> 
#include <math.h>

int main(void)
{

float c; //saying c(ash) is a float point number

do
    {
        c = get_float("How much change is owed?\n"); //asking user for input
    } while (c<=0); //keep asking, if c is or is below 0, or not an int

int RT = 0; //initialising a Running Total counter for all coins
int change = round(c*100); //turning c into dollars

// checking if quarters can be used, then decreasing by 25, and adding to running total
while(change >= 25) //a while loop is a (condition) and then code is executed as long as condition is TRUE, once it is false program moves on
    {
        change -= 25;
        RT++;
    }

// ditto for dimes
while(change >= 10)
    {
        change -= 10;
        RT++;
    }
// ditto for nickels
while(change >= 5)
    {
        change -= 5;
        RT++;
    }
// ditto for pennies
while(change >= 1)
    {
        change -= 1;
        RT++;
    }

printf("%i coins\n", RT); //printing no. of times loops are run
}
        
     
          
