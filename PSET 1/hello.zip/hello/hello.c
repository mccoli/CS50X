#include <stdio.h>

//in order to use string, etc.
#include <cs50.h> 

int main(void) 
{
    //name is the variable, get is like ask
    string name = get_string("what's your name?\n"); 
    
    //%s is a placeholder for string, name is the variable
    printf("hello, %s\n", name);
}