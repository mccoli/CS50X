#include <stdio.h>
#include <cs50.h>

int main(void)
{
int i; //saying what kind of variable it is, user input

do
{

  i = get_int("Height between 1 and 8:\n"); //ask this q and start a new line if...

} while (i<1 || i>8);                       //...the user ISN'T putting in an int between 1 and 8

//left-aligned hash triangle
  for(int r=0; r<i; r++)         //start at 0, check if no. of rows is less than user input, then start a new row
   {
       for(int d=i-2; d>=r; d--)    //pushing #TRI to the R//start w the no. of dots given by user input, check if more . than R,Go down by 1
      {                             //MISTAKE prints an extra character
       printf(" "); 
      }
     for(int x=0; x<=r; x++)     //start at 0, condition is x must be less than or equal to the no of rows, then add a "#"
     {
      printf("#");
     }
    printf("\n");
   }

    
}
