#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <stdlib.h>

int k, s, u, l, f;

int main(int argc, string argv[]) //takes a # of clas, can see them as strings
{
    if(argc == 2) //if there are 2 arguments...
    {//validating the key
        for(int c = 0; argv[1][c] != '\0'; c++) //iterating thru chars in key
        {
            if(isdigit(argv[1][c]) != 0) //is the char a digit?
            {
                k = atoi(argv[1]); //turns a string '20' into the actual int 20
            }
            else
            {
                printf("error\n");
                return 1;
            }
        }
        string pt = get_string("plaintext: ");

        printf("ciphertext: ");
        for(s = 0; pt[s] != '\0'; s++) //iterating thru pt string
        {
            if(isalpha(pt[s]) != 0) //if the char is an alpha
            {
                if(isupper(pt[s]) != 0) //if the char is uppercase
                {
                    u = pt[s] - 65; //uppercase alpha index
                    f = ((u + k) % 26) + 65; //enciphering with key
                    printf("%c", f); //printing letter
                }
                else
                {
                    l = pt[s] - 97; //lowercase alpha index
                    f = ((l + k) % 26) + 97; //enciphering with key
                    printf("%c", f);
                }
            }
            else
            {
                printf("%c", pt[s]); //prints original pt for blanks, punctuation, numbers etc.
            }
        }
        printf("\n"); //after ct for terminal tidiness
        return 0; 
    }
    return 1; //exits code with error
}