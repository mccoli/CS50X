#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include "customs.h"
#include "main.h"

//plugging values into Coleman-Liau Formula
int cl_formula()
{

    int a = (0.0588 * L) / (100 * W);     //letters

    int b = (0.296 * S) / (100 * W);     //sentences

    int i = a - b - 15.8;  //summing formula

int index = round (i); //rounding to nearest int

return index; //final sum
} //something is wrong in the maths! returns "Grade -15" no matter what


//counts the # of letters in an inputted text! :)
int count_letters() //defining function
{

    L = 0; //setting a counter for letters at 0

    //iterating thru whole string
    for(int s = 0; txt[s] != '\0' ; s++) //starts counting from 0, checks that txt string has NOT reached null \0, counts up by one
    {
        //checking for alphabet letters
        if(isalpha(txt[s]) != 0) //isalpha returns non0 if IS alpha
        L++; //+1 to letters counter
    }
return L; //telling program to use letter counter value if program works
}

//should count the # of words in an inputted text
int count_words()
{
    W = 0; //setting a counter for spaces at 0

    //iterating thru string
    for(int s = 0; txt[s] != '\0'; s++)
    {
        if(isblank(txt[s]) !=0) //if there is a blank character, i.e. space or tab...
        W++; //count up by one
    }
return W+1; //a three word sentence only has two spaces
}

//should count the # of sentences
int count_sentences()
{
    S = 0; //setting a counter for sentences at 0

    //iterating thru string
    for(int s = 0; txt[s] != '\0'; s++)
    {
        if(txt[s] == '.' || txt[s] == '!' || txt[s] == '?') //if there is any of these
        S++; //count up by one
    }
return S;
}

