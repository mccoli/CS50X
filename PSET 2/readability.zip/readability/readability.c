#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <math.h>

int L = 0; //setting a counter for letters at 0
int W = 1; //setting a counter for words at 1 (there is always 1 less space than words)
int S = 0; //setting a counter for sentences at 0
int cl_formula();

//code needs simplifying once debugged...Don't Repeat Yourself!!
int main(void)
{

    string txt = get_string("Text: ");

    //iterating thru whole string
    for(int s = 0; txt[s] != '\0' ; s++) //starts counting from 0, checks that txt string has NOT reached null \0, counts up by one
    {
        //checking for alphabet letters
        if(isalpha(txt[s]) != 0) //isalpha returns non0 if IS alpha
        {
            L++;
        }
        
        if(txt[s] == ' ') //if there is a blank character
        {
            W++;
        }
        
        if(txt[s] == '.' || txt[s] == '!' || txt[s] == '?') //if there is any of these
        {
            S++;
        }
    }

    int x = cl_formula(); //calling coleman-liau formula function

    if (x > 16)
    {
        printf("Grade 16+\n");
    }
    else if (x < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", x);
    }
}

//plugging values into Coleman-Liau Formula
int cl_formula()
{

    float a = 100.0 * L / W ;
                                      
    float b = 100.0 * S / W;

    float i = round((0.0588 * a) - (0.296 * b) - 15.8); 

    return i;
}