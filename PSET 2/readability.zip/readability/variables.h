#include <cs50.h>

string txt;
float W;
float S;