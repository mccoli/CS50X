#include "helpers.h"
#include <math.h>
#include <stdio.h>

//Convert image to grayscale :)
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    //looping thru rows
    for (int h = 0; h <= height - 1; h++)
    {
        //looping thru columns
        for (int w = 0; w <= width - 1; w++)
        {
            //acces to individual pixel
            float pixel_avg = (image[h][w].rgbtRed + image[h][w].rgbtGreen + image[h][w].rgbtBlue) / 3.0;

            pixel_avg = round(pixel_avg);

            image[h][w].rgbtRed = pixel_avg;
            image[h][w].rgbtGreen = pixel_avg;
            image[h][w].rgbtBlue = pixel_avg;
        }
    }
    return;
}

//Convert image to sepia :)
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    float sepiaRed, sepiaGreen, sepiaBlue;
    float red, green, blue;

    //rows
    for (int h = 0; h <= height - 1; h++)
    {
        //columns
        for (int w = 0; w <= width - 1; w++)
        {
            //recording values for formula use
            red = image[h][w].rgbtRed;
            green = image[h][w].rgbtGreen;
            blue = image[h][w].rgbtBlue;

            //sepia formula
            sepiaRed = round((0.393 * red) + (0.769 * green) + (0.189 * blue));
            sepiaGreen = round((0.349 * red) + (0.686 * green) + (0.168 * blue));
            sepiaBlue = round((0.272 * red) + (0.534 * green) + (0.131 * blue));

            if (sepiaRed > 255)
            {
                sepiaRed = 255;
            }

            if (sepiaGreen > 255)
            {
                sepiaGreen = 255;
            }

            if (sepiaBlue > 255)
            {
                sepiaBlue = 255;
            }

            image[h][w].rgbtRed = sepiaRed;
            image[h][w].rgbtGreen = sepiaGreen;
            image[h][w].rgbtBlue = sepiaBlue;
        }
    }
    return;
}

//Reflect image horizontally :)
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    int half_width = round(width * 0.5);

    //rows
    for (int h = 0; h <= height - 1; h++)
    {
        //columns
        for (int w = 0; w <= width - 1; w++)
        {
            while (w < half_width)
            {
                RGBTRIPLE temp = image[h][w];
                image[h][w] = image[h][width - w - 1];
                image[h][width - w - 1] = temp;
                break;
            }
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE imgcpy[height][width];

    //duplicating original image into copy so I can have original pixels for blurring
    for (int h = 0; h <= height - 1; h++)
    {
        for (int w = 0; w <= width - 1; w++)
        {
            imgcpy[h][w] = image[h][w];
        }
    }

    for (int h = 0; h <= height -1; h++)
    {
        for (int w = 0; w <= width - 1; w++)
        {
            int red = 0;
            int green = 0;
            int blue = 0;
            float counter = 0.0; //for avg formula

            //looking at pixels surrounding 1 pixel
            for (int n = - 1; n <= 1; n++) //setting bounds for rows. -1, 0, 1
            {
                for (int m = - 1; m <= 1; m++) //setting bounds for columns
                {
                    if (n + h != height &&
                        n + h != - 1 &&
                        m + w != width &&
                        m + w != - 1)
                    {
                    //!!index 600 out of bounds for RGBTRIPLE [width]

                    //getting rgb values of pixel and surroundings
                    red += imgcpy[n + h][m + w].rgbtRed;
                    green += imgcpy[n + h][m + w].rgbtGreen;
                    blue += imgcpy[n + h][m + w].rgbtBlue;

                    counter++;
                    //sizeof showed width as 1800?
                    }
                }
            }

            //getting averages for each channel
            image[h][w].rgbtRed = round(red / counter);
            image[h][w].rgbtGreen = round(green / counter);
            image[h][w].rgbtBlue = round(blue / counter);
        }
    }
    return;
}


