#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define BUFFER 512

int main(int argc, char *argv[])
{
    //checking for correct usage
    if (argc != 2)
    {
        printf("Usage: ./recover image \n");
        return 1;
    }

    //opening file inputted by user
    FILE  *card = fopen(argv[1], "r");
    if (card == NULL)
    {
        printf("Error: file could not be opened\n");
        return 2;
    }

    //declaring array big enough to hold 512B blocks
    unsigned char raw[BUFFER];

    //variables for creating jpegs in 000.jpg format
    char filename[8];
    int file_count = 0;
    FILE *img = NULL;

    //reading bytes in 512 size blocks
    while ((fread(raw, BUFFER, 1, card)) == 1)
    {
        //checking it is a new JPEG
        if (raw[0] == 0xff && raw[1] == 0xd8 && raw[2] == 0xff && (raw[3] & 0xf0) == 0xe0)
        {
            //close last file
            if (file_count != 0)
            {
                fclose(img);
            }

            //opening JPEG for writing with specified format
            sprintf(filename, "%03i.jpg", file_count);
            img = fopen(filename, "w");
            file_count++;
        }

        //writing if output file is open
        if (img != NULL)
        {
            //writing blocks to file
            fwrite(&raw, BUFFER, 1, img);
        }
    }

    fclose(card);
    fclose(img);
    return 0;
}