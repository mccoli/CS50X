// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "dictionary.h"
#define N 65536 //2^16 allows for bitwise operations

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

int word_count = 0;

// Hash table
node *table[N];

//4.Returns true if word is in dictionary else false
bool check(const char *word)
{
    int i = hash(word);
    node *traveler = table[i];

    //!traveler is always null!
    while (traveler != NULL)
    {
        if (strcasecmp(table[i]->word, word) == 0)
        {
            return true;
        }
        traveler = traveler->next;
    }
    return false;
}

//2.Hashes word to a number
unsigned int hash(const char *word)
{
    unsigned long hash = 5381;
    int c = *word;

    c = tolower(c);

    while (*word != 0)
    {
        hash = ((hash << 5) + hash) + c;
        c = *word++;
        c = tolower(c);
    }
    return hash % N;
    //source: modified ver. "djb2" by dan bernstein original accessed at: <http://www.cse.yorku.ca/~oz/hash.html>. modified accessed at: <https://www.reddit.com/r/cs50/comments/eo4zro/good_hash_function_for_speller/> (4/9/20)
}

//1.Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    char word[LENGTH + 1];

    FILE *d = fopen(dictionary, "r");
    if (d == NULL)
    {
        printf("Could not open the file\n");
        return false;
    }

    //reading each string in dictionary
    while (fscanf(d, "%s", word) != EOF)
    {
        //creating a new node for each word
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return false;
        }
        strcpy(n->word, word);
        int i = hash(word);

        //if that index point is empty, put the node there
        if (table[i] == NULL)
        {
            n->next = NULL;
            table[i] = n;
        }
        else
        {
            n->next = table[i];
            table[i] = n;
        }
        word_count++;
    }
    fclose(d);
    return true;
}

//3. Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    return word_count;
}

//5. Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    for (int i = 0; i < 65536; i++)
    {
        node *traveler = table[i];
        node *tmp = traveler;

        while (traveler != NULL)
        {
            traveler = traveler->next;
            free(tmp);
            tmp = traveler;
        }
    }
    return true;
}
