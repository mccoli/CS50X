#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

//maximum value of hash int
#define HASH_MAX 26

//creating a node that contains a name and a next field
typedef struct node
{
    char *name;
    struct node *next;
}
node;

}
int main(void)
{
    //initialising the head of the list as size 26 and empty
    node *table[HASH_MAX] = {NULL};

    //creating a new node
    node *n = malloc(sizeof(node));
    if (n == NULL)
    {
        return 1;
    }

    //getting user input for population
    char *input = get_string("Enter name: ");
    char *input1 = get_string("Enter name: ");
    char *input2 = get_string("Enter name: ");
    
    int hashvalue = hash(input);
    insert(hashvalue, name);
    
    //populating node n and inserting into list
    n->name = input;
    n->next = NULL;
    table = n;

    n = malloc(sizeof(node));
    if (n == NULL)
    {
        return 1;
    }
    
    n->name = input1;
    n->next = NULL;
    table->next = n;

    n = malloc(sizeof(node));
    if (n == NULL)
    {
        return 1;
    }
    
    n->name = input2;
    n->next = NULL;
    table->next->next = n;

    //printing the list
    for (node *tmp = table; tmp != NULL; tmp = tmp->next)
    {
        printf("%s\n", tmp->name);
    }

    //traversing and freeing list (list is n)
    while (table != NULL)
    {
        node *tmp = table->next;
        free(table);
        table = tmp;
    }

}