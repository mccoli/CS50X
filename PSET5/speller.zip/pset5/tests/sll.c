#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

//creating a node that contains a name and a next field
typedef struct node
{
    char *name;
    struct node *next;
}
node;

int main(void)
{
    //initialising a list of nodes of no current value
    node *list = NULL;

    //creating a new node
    node *n = malloc(sizeof(node));
    if (n == NULL)
    {
        return 1;
    }

    //getting user input for population
    char *input = get_string("Enter name: ");
    char *input1 = get_string("Enter name: ");
    char *input2 = get_string("Enter name: ");

    //populating node n and inserting into list
    n->name = input;
    n->next = NULL;
    list = n;

    n = malloc(sizeof(node));
    if (n == NULL)
    {
        return 1;
    }

    n->name = input1;
    n->next = NULL;
    list->next = n;

    n = malloc(sizeof(node));
    if (n == NULL)
    {
        return 1;
    }

    n->name = input2;
    n->next = NULL;
    list->next->next = n;

    //printing the list
    for (node *tmp = list; tmp != NULL; tmp = tmp->next)
    {
        printf("%s\n", tmp->name);
    }

    //traversing and freeing list (list is n)
    while (list != NULL)
    {
        node *tmp = list->next;
        free(list);
        list = tmp;
    }

}