from sys import argv
import csv
import re

def get_max(sub, full):
    #SOURCE: https://www.geeksforgeeks.org/python-maximum-consecutive-substring-occurrence/
    max_groups = max(re.findall('((?:' + re.escape(sub) + ')*)', full), key = len)

    return int((len(max_groups) / len(sub)))

def main():

    if len(argv) != 3:
        print("Error. Usage: python dna.py database.csv sequence.txt")

    #opening dna sequence
    with open(argv[2], 'r') as dna:
        sequence = dna.read()

    #opening csv file
    with open(argv[1], 'r') as data:
        reader = csv.reader(data)

        #collecting str names
        strs = next(reader)[1:]

        #updating as a list with str counts
        str_list = [str(get_max(i, sequence)) for i in strs]

        #comparing the data
        for row in reader:
            name = row[0]
            values = row[1:]
            if values == str_list:
                print(name)
                return

        print("no match")

main()