import csv
import os
from sys import argv

max_repeat = 0

if len(argv) != 3:
    print("Error. Usage: python dna.py database.csv sequence.txt")

#figuring out which sequence to look at
if '.txt' in argv[2]:
    os.chdir('sequences/')
    for file in os.listdir():
        if file == argv[2]:
            print("found") #deb
            f = open(file)
            seq = f.read() #holding the sequence
            os.chdir('..') #going back out to 'dna/'
            break

#opening file and initialising counters for STRs
if 'small.csv' in argv[1]:
    with open('databases/small.csv', 'r') as file:
        s_reader = csv.reader(file)
        a, b, c = 0, 0, 0

        #looking at (small.csv) STRs to count up
        #successful but verbose...try for a better design (imagine this w/ large.csv)
        #could build an algorithm that builds a dict as it goes (regardless of csv)

        for i in range(len(seq)): #goes char by char
            j = i + 5
            k = i + 4

            if seq[i:j] == 'AGATC': #comparison of size 5
                a += 1
            if seq[i:k] == 'AATG': #of size 4
                b += 1
            if seq[i:k] == 'TATC':
                c += 1

            if a > max_repeat:
                max_repeat = a
            elif b > max_repeat:
                max_repeat = b
            elif c > max_repeat:
                max_repeat = c
