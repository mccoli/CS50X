from sys import argv
import csv

#function that finds the maximum consecutive STRs in a sequence INSPO/SOURCE: https://stackoverflow.com/questions/61444287/cs50-dna-works-for-small-csv-but-not-for-large
def get_max(substring, full_string):

    #setting variables for easier use later
    for substring in full_string:
        longest = 0
        current = 0
        i = 0
        STR = len(substring)

    #traversing through sequence looking for matches
    while i < len(full_string):
        if full_string[i : i + STR] == STR:
            current += 1
            if i + STR <= len(full_string):
                i = i + STR #incrementing manually by key size
            continue
        if current > longest:
            longest = current
            current = 0
        i += 1

    return longest

def main():

    if len(argv) != 3:
        print("Error. Usage: python dna.py database.csv sequence.txt")

    #opening dna sequence
    with open(argv[2], 'r') as dna:
        sequence = dna.read()

    #opening csv file
    with open(argv[1], 'r') as data:
        reader = csv.DictReader(data)

        #collecting str names based on csv opened
        str_holder = {}
        for row in reader:
            for column, value in row.items():
                str_holder.setdefault(column, []).append(value)

        #traversing sequence for strs
        for key in str_holder.keys():
            max_repeats = int(get_max(key, sequence))

            #updating my dictionary
            for column, value in str_holder.items():
                str_holder.update({key : max_repeats})
            print(str_holder)
        #comparing the data
        with open(argv[1], 'r') as data:
            reader = csv.DictReader(data)

            #looking for a match between databases
            for row in reader:
                matches = 1
                for column, value in row.items():
                    if value.isnumeric() == True:
                        value = int(value)
                        for val in str_holder.values():
                            if val == value:
                                matches += 1
                                if matches == len(str_holder.values()):
                                    print(row['name'])

        #emptying dictionary for next use
        str_holder.clear()
main()
        #goes after line 30. freezes on large.csv, works for small: max_groups = max(re.findall('((?:' + re.escape(key) + ')*)', sequence), key = len) #SOURCE: https://www.geeksforgeeks.org/python-maximum-consecutive-substring-occurrence/