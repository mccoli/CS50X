from cs50 import get_int

while True:
    h = get_int("Height: \n")
    if 0 < h < 9:
        break

for r in range(h):
    for d in range(h - 1, r, -1):
        print(" ", end = "")
    for i in range(r + 1):
        print("#", end = "")
    print()
