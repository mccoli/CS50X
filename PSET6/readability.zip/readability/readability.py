from cs50 import get_string

def formula():
    x = float(100 * l / w)
    y = float(100 * s / w)

    grade = round(0.0588 * x - 0.296 * y - 15.8)

    return grade

text = get_string("Text: ")

l, w, s = 0, 1, 0 #counters

for c in text:
    if c.isalpha():
        l += 1
    if c.isspace():
        w += 1
    if c in [".", "?", "!"]:
        s += 1

index = formula()

if index > 16:
    print("Grade 16+")
elif index < 1:
    print("Before Grade 1")
else:
    print(f"Grade {index}")