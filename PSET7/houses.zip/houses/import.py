from sys import argv
from cs50 import SQL
import csv

if len(argv) != 2:
    print("Error. Usage: import.py characters.csv")

#creating a connection oject
db = SQL("sqlite:///students.db")

#opening characters.csv
with open(argv[1], 'r') as c:
    reader = csv.reader(c)

    #ignoring name header
    row = next(reader)[1:]

    #collecting data
    for row in reader:
        name = [row[0].split()]
        house = [row[1]]
        birth = [row[2]]

        #inserting into database
        for n in name:
            if len(n) < 3:
                first = n[0]
                middle = 'None'
                last = n[1]
                db.execute("INSERT INTO students(first, middle, last, house, birth) VALUES (:first, :middle, :last, :house, :birth)", first=first, middle=middle, last=last, house=house, birth=birth)
            else:
                first = n[0]
                middle = n[1]
                last = n[2]
                db.execute("INSERT INTO students(first, middle, last, house, birth) VALUES (:first, :middle, :last, :house, :birth)", first=first, middle=middle, last=last, house=house, birth=birth)