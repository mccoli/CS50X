from sys import argv
from cs50 import SQL

if len(argv) != 2:
    print("Error. Usage: python roster.py house")

#recording input
house = argv[1]

#creating a connection oject
db = SQL("sqlite:///students.db")

#querying for students in given house
results = db.execute("SELECT first, middle, last, birth FROM students WHERE house IN (:house) ORDER BY last, first", house=house)

#printing results
for i in range(len(results)):
    print(results[i]['first'], end=' ')

    if (results[i]['middle'] != 'None'):
        print(results[i]['middle'], end=' ')

    print(f"{results[i]['last']},", end=' ')
    print(f"born {results[i]['birth']}")